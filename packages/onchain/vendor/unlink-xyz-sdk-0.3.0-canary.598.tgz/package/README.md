# `@unlink-xyz/sdk`

TypeScript SDK for [Unlink](https://docs.unlink.xyz) - privacy-as-a-service on
EVM chains. UTXO model with ZK proofs (Groth16). Send, receive, and execute
privately on existing blockchains.

## Install

```bash
npm install @unlink-xyz/sdk@canary
pnpm add @unlink-xyz/sdk@canary
yarn add @unlink-xyz/sdk@canary
bun add @unlink-xyz/sdk@canary
```

The current SDK surface is published on the `canary` npm dist-tag.
Requires Node.js 18+. ESM-only. The SDK includes EIP-1193, viem, ethers, and
custom signer adapters. Install viem or ethers only if your app imports those
packages directly.

## Hosted Deployments

The SDK connects to hosted deployments by `environment` name. Each environment
maps to one chain and Engine URL.

- `base-sepolia` - Base Sepolia, available now
- `ethereum-sepolia` - Ethereum Sepolia, available now
- `arc-testnet` - Arc testnet, available now
- `monad-testnet` - Monad testnet, coming soon
- `monad` - Monad Mainnet, coming soon
- `base` - Base Mainnet, coming soon

Available hosted environments are exported as `ENVIRONMENTS`. Pass `engineUrl`
instead for local or custom deployments. New production environments will become
available as their chain deployments are published.

## Choose Custody Model

Choose the SDK entry from the custody model first.

- Non-custodial browser apps import from `@unlink-xyz/sdk/browser`.
- Custodial servers, CLIs, workers, and agents import from `@unlink-xyz/sdk/client`.

Both models use `@unlink-xyz/sdk/admin` on your backend for registration,
authorization tokens, and backend reads.

## Browser Non-Custodial

```ts
import { account, createUnlinkClient } from "@unlink-xyz/sdk/browser";

const { account: unlinkAccount } = await account.fromMetaMask({
  provider: window.ethereum,
  appId: "your-app-id",
  chainId: 84532,
});

const me = createUnlinkClient({
  environment: "base-sepolia",
  account: unlinkAccount,
});

await me.ensureRegistered();
const tx = await me.transfer({ recipientAddress, token, amount });
await tx.wait();
```

The user client authenticates with short-lived authorization tokens issued by
your backend. The admin API key never ships to browser bundles.

## React

`@unlink-xyz/sdk/react` wraps the browser client in one hook. `react` is an
optional peer — install it in your app.

```tsx
import { account, createUnlinkClient } from "@unlink-xyz/sdk/browser";
import { UnlinkProvider, useUnlink } from "@unlink-xyz/sdk/react";

const { account: unlinkAccount } = await account.fromMetaMask({
  provider: window.ethereum,
  appId: "your-app-id",
  chainId: 84532,
});

const client = createUnlinkClient({
  environment: "base-sepolia",
  account: unlinkAccount,
});

function App() {
  return (
    <UnlinkProvider client={client}>
      <Wallet />
    </UnlinkProvider>
  );
}

function Wallet() {
  const { status, balances, transfer } = useUnlink();
  if (status !== "ready") return <p>Loading…</p>;
  const send = async () => {
    try {
      await transfer({ recipientAddress, token, amount });
    } catch (err) {
      // Actions reject on failure — handle it (toast, retry, …).
    }
  };
  return <button onClick={send}>Send</button>;
}
```

`UnlinkProvider` takes a ready `client` (above) or a `config` object it builds
the client from; both are read once on first render. The provider registers the
user and loads balances on mount, so no explicit `ensureRegistered()` is needed.
`useUnlink()` returns reactive `status`, `address`, `balances`, `transactions`,
and `error`, plus `refresh` and the `deposit` / `depositWithApproval` /
`transfer` / `withdraw` / `execute` actions — each waits for completion, then
refreshes (pass `TransactionHandleWaitOptions` for an abort signal, status
callback, or timeout). Reach `client` for anything not surfaced here (execution
accounts, faucet, approval, polling, or a fire-and-forget handle).

Notes:

- **Actions reject on failure.** The snapshot `error` reflects the data load
  (`refresh`), not actions — `try`/`catch` your `transfer`/`deposit`/… calls.
- **Switching account/client.** `client`/`config` are read once; to follow a
  wallet or account switch, remount the provider with a React `key`.
- **React version.** Runtime peer is `react >=18 <20`; the published types
  typecheck cleanly under both `@types/react@18` and `@types/react@19`.

## Backend Routes

```ts
import {
  createUnlinkAdmin,
  createUnlinkAuthRoutes,
} from "@unlink-xyz/sdk/admin";

const admin = createUnlinkAdmin({
  environment: "base-sepolia",
  apiKey: process.env.UNLINK_API_KEY!,
});

const routes = createUnlinkAuthRoutes({
  admin,
  authenticate: async (request) => getAppSession(request),
  onRegister: async ({ session, registration }) => {
    await db.linkUnlinkAddress(session.userId, registration.address);
  },
  authorizeUnlinkAddress: async ({ session, unlinkAddress }) =>
    db.userOwnsUnlinkAddress(session.userId, unlinkAddress),
});

app.post("/api/unlink/register", (c) => routes.register(c.req.raw));
app.post("/api/unlink/authorization-token", (c) =>
  routes.authorizationToken(c.req.raw),
);
```

## Server Or Custodial Client

```ts
import { createUnlinkAdmin } from "@unlink-xyz/sdk/admin";
import { account, createUnlinkClient } from "@unlink-xyz/sdk/client";

const admin = createUnlinkAdmin({
  environment: "base-sepolia",
  apiKey: process.env.UNLINK_API_KEY!,
});

const unlinkAccount = account.fromMnemonic({ mnemonic });
const unlinkAddress = await unlinkAccount.getAddress();

const me = createUnlinkClient({
  environment: "base-sepolia",
  account: unlinkAccount,
  register: (payload) => admin.users.register(payload),
  authorizationToken: {
    provider: () => admin.authorizationTokens.issue({ unlinkAddress }),
  },
});
```

## Admin Reads

```ts
const user = await admin.users.get({ address: unlinkAddress });
const balances = await admin.users.getBalances({ address: unlinkAddress });
const transactions = await admin.users.getTransactions({
  address: unlinkAddress,
  status: "processed",
  limit: 20,
});
const auth = await admin.authorizationTokens.issue({ unlinkAddress });
```

## User Actions

High-level user clients expose:

- `ensureRegistered()`
- `depositWithApproval(params)`
- `transfer(params)`
- `withdraw(params)`
- `execute(params)`
- `getBalances(params?)`
- `getTransactions(params?)`
- `faucet.requestTestTokens(params)`
- `faucet.requestPrivateTokens(params)`

Signing is derived from the account bound to `createUnlinkClient`. `fromKeys`
supports transfer and withdrawal. `execute()` requires a seed-backed account.

## Errors

All SDK errors extend `UnlinkError` with a `code` discriminator.

- `ApiError` - backend rejected the call.
- `CapabilityError` - missing provider/account capability, auth rotation failure, or unsupported execution account.
- `ValidationError` - caller-side argument check failed.
- `TimeoutError` - poll loop exceeded its deadline.

## Versioning

This SDK is `0.3.x` - pre-1.0. Minor changes can be breaking. The 1.0 cut will
lock the public surface defined by the subpath snapshots checked into CI
(`src/__tests__/__snapshots__/surface-snapshot.test.ts.snap`).

## License

Apache-2.0. See [LICENSE](LICENSE).
